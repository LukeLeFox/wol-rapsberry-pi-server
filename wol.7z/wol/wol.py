# Load libraries
from bottle import route, run, template
from wakeonlan import send_magic_packet

# Handle http requests to the root address
@route('/')
def index():
 return 'Allontanati, ti attende solo la rovina.'

# Handle http requests to /subdir
@route('/wakeitup/')
def wol():
 send_magic_packet('40-b0-76-09-0a-e2')
 return 'WOL! BABYYYYYYYYYYYYYYYYYYYYYY'

run(host='192.168.1.11', port=8888)
